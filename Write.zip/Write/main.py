print("===============> Welcome to exam test <===============");
print("Student: Mladen Jovanovic");
print("Broj indeksa: M5/2019");
print("Profesor: dr Milica Tufegdžić, prof.");
while True :
    cho_num = int(input("---Izaberite opciju:\r\n1)Upis u fajl \r\n2)Citanje fajla\r\n0)Izlaz\r\n"));

    if cho_num == 1 :
        file_writter = open('test_file.txt', 'w');
        text_writter = str(input("Unesite tekst: "));
        text = file_writter.write((text_writter));
        print("Bravo! Tekst je uspesno sacuvan u fajl!");
        file_writter.close();
    elif cho_num == 2 :
        file_reader = open('test_file.txt', 'r');
        text_reader = file_reader.read();
        print("-------------------> Pocetak teksta! <------------------- ");
        print(text_reader);
        print("-------------------> Kraj teksta! <-------------------")
        file_reader.close();
    elif cho_num == 0 :
        exit();
    else :
        print("Ne postoji opcija!");
